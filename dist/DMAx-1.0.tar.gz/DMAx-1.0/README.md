# DMAx
A high-throughput workflow for Dynamic Mechanical Analysis simulations with LAMMPS
